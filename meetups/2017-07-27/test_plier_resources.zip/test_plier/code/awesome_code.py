import time


def work_hard():
    time.sleep(0.5)
    print('"Lightning" == "Talk"?')
    return "Lightning" == "Lightning"


def work_harder():
    time.sleep(1.01)
    print('"Python" > "Awesome"!')
    return "Python" > "Awesome"


def sir_work_alot(foo=None):
    time.sleep(1.02)
    print('"You" >= "Rock"!')
    return "You" >= "Rock" and foo != 'spam'
    # return True
