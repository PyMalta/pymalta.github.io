from awesome_code import sir_work_alot


def test_foo_1():
    assert sir_work_alot()


def test_foo_2():
    """ Testing foo #2 """
    assert sir_work_alot(foo='bar')


def test_foo_3():
    assert sir_work_alot()


def test_foo_4():
    assert sir_work_alot(foo='bar')


def test_foo_5():
    assert not sir_work_alot(foo='spam')


def test_foo_6():
    assert sir_work_alot(1) == 5


def test_foo_7():
    assert sir_work_alot()


def test_foo_8():
    assert sir_work_alot() == 1


class TestCase(object):
    def test_me(self):
        self.assertEqual('self')


def test_foo_9():
    assert sir_work_alot()


def test_foo_10():
    assert sir_work_alot()
